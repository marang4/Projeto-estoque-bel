package br.com.senac.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientesBackendApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientesBackendApiApplication.class, args);
	}

}
