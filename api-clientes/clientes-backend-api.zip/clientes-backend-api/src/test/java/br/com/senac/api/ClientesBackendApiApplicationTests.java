package br.com.senac.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientesBackendApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
